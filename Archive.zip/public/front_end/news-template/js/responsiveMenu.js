$(document).ready(function(){
    $(".menuIcon").click(function(){
        $(".menu").slideToggle()
    })
})