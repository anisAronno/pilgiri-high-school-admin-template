<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\BaseController;

use Illuminate\Http\Request;

class PhoneOtpController extends BaseController
{
    //
}
